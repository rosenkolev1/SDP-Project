﻿// SDP project.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <map>
#include "SkipList.h"
#include "StringManip.h"
#include "UndirectedGraph.h"
#include <fstream>
#include <queue>
#include "Box.h"
#include "Task 1.h"
#include "Task 2.h"

int main()
{
    //TASK 1
    //copyConstructorTest1();
    /*for (int i = 0; i < 1000000; i++)
    {
        copyConstructorTest2();
    }*/

    /*task1(std::cout, std::cin);*/

    //TASK 2
    /*constructorTest3();
    std::ifstream is("Plovdiv.txt");
    std::cout << task2(is);
    is.close();
    
    std::cout << std::endl;*/
    
    /*std::ifstream is2("test_task2.txt");
    std::cout << task2(is2);
    is2.close();*/

    //TASK3 
    /*for (int i = 0; i < 1000000; i++)
    {
        copyConstructorTest4();
    }  */
    /*copyConstructorTest4();*/

    /*std::ifstream is3("boxesList.txt");
    std::cout << task3(is3);
    is3.close();*/

    /*std::ifstream is4("test_task3_boxesList.txt");
    std::cout << task3(is4);
    is4.close();*/
}
