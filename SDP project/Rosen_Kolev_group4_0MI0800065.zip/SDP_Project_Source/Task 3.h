#pragma once
#include <fstream>

std::string task3(std::ifstream& in);